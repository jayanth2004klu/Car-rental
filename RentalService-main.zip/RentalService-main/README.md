# MERN-RENTAL-Service-APP
This is a Full Stack (MERN) car rental Application with admin panel & ant design for styling components and to book cars with the cars availability. It is developed using React for Front End , Redux-Thunk for Asynchronous operations,
Node JS for Runtime environment , Express JS for Backend Routing and Mongo DB for Database


Heroku-link: https://mern-athifcars-rental-app.herokuapp.com/ <br>
